from lib.utils.cipher.shiro import hasher
