linux_db_host = "jerhz-cluster.cluster-csdbzz5e1rot.us-east-1.rds.amazonaws.com"
linux_db_name = "linux"
linux_db_user = "dbadmin"
linux_db_password = "Passw0rd!"

zeppelin_db_host = "jerhz-cluster.cluster-csdbzz5e1rot.us-east-1.rds.amazonaws.com"
zeppelin_db_name = "zeppelin"
zeppelin_db_user = "dbadmin"
zeppelin_db_password = "Passw0rd!"

jerhz_dir = "/var/lib/jerhz"
jerhz_efs_dir = jerhz_dir + "/efs"
